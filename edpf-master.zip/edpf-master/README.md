<h1>Projeto final de Estrutura de Dados : Banco de dados em arvore/tabela hash de uma clínica de doação de sangue</h1>

<h2>Pré requisitos</h2>
<ul>
	<li>make</li>
	<li>gcc</li>
</ul>

<h2>Compilar</h2>
<p>Basta utilizar <code>make</code> na pasta raiz que resultara em dois binários, bbmed e benchmark