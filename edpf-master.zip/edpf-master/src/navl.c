#include "navl.h"
void navl_insert(NavlNode** ht,BaseNode* n){
	//..
}
NavlNode* navl_new(){
	return 0;
	
}
