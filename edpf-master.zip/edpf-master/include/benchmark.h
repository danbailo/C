#ifndef BENCHMARK
#define BENCHMARK
#include <time.h>
#include <unistd.h>
#endif