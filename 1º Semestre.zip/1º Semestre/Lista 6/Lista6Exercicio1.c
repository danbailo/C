#include <stdio.h>
#include <stdlib.h>

struct escola{
  char nome[32];
  int numero;
};

struct escola cadastro[10];

int main(){
  int cont,n,num;
    printf("CADASTRO\n");
    for(int i=0;i<10;i++){
      printf("Digite o nome do %dº aluno: ",i+1);
      gets(cadastro[i].nome);
      printf("Digite o número do %dº aluno: ",i+1);
      scanf("%d",&cadastro[i].numero);
      printf("\n");
      getchar();
    }
    do{
    printf("PESQUISAR ALUNO\n");
    printf("Digite o número do aluno: ");
    scanf("%d",&n);
    for(int i=0;i<10;i++){
      num=cadastro[i].numero;
      if(n==num){
        printf("O nome do aluno é %s\n",cadastro[i].nome);
      }
    }
    printf("Deseja continuar ? [1]SIM [0]NÃO\n");
    scanf("%d",&cont);
    getchar();

  }while(cont!=0);
}
