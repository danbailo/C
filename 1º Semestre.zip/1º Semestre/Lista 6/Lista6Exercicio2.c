#include <stdio.h>
#include <stdlib.h>

struct escola{
  int rga;
  char nome;
  float nota;
};

struct escola esc[10];

int main(){

  int rga[10];
  char nome[10];
  float nota[10];

  for(int i=0;i<10;i++){
    printf("Digite o RGA do %dº aluno: ",i+1);
    scanf("%d",&rga[i]);
    getchar();
    printf("Digite o NOME do %dº aluno: ",i+1);
    gets(nome);
    printf("Digite a NOTA do %dº aluno: ",i+1);
    scanf("%f",&nota[i]);
    getchar();
    printf("\n");
  }
  for(int i=0;i<10;i++){
    esc[i].rga=rga[i];
    esc[i].nota=nota[i];
    esc[i].nome=nome[i];
  }
}
