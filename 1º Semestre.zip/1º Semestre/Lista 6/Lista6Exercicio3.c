#include <stdio.h>
#include <stdlib.h>

struct carro{
  char proprietario;
  char combustivel;
  int modelo;
  char cor;
  char chassi;
  unsigned int ano;
  char placa;
};

struct carro car[20];

int main(){
  


}
