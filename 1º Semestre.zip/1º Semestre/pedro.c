#include <stdio.h>
#include <locale.h>
#include <string.h>

typedef struct{
	int rga[10];
	char nome[10][50];
	float nota[10];
}estrutura;

void main(){

	setlocale(LC_ALL,"portuguese");

	estrutura e1[10];
	int rga[10], i;
	char nome[10][50];
	float nota[10], temp;

	for(i = 0; i < 10; i++){
		printf("Digite o RGA do aluno: ");
		scanf("%d", &rga[i]);

		printf("\n");

		printf("Digite o nome do aluno: ");
		getchar( );
		gets(nome[i]);

		printf("\n");

		printf("Digite a nota do aluno: ");
		scanf("%f", &nota[i]);

		printf("\n");
	}

	for(i = 0; i < 10; i++){
		strcpy(e1[i].nome[i], nome[i]);
		e1[i].rga[i] = rga[i];
		e1[i].nota[i] = nota[i];
	}
}
