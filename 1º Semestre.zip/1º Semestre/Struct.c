#include <stdio.h>
#include <stdlib.h>

struct componente {
  char tipo[20];
  char referencia[4];
  unsigned char num_ref;
  int valor;
  char unidade[10];
};

struct componente comp;

int main(){
  printf("Tipo do componente: ");
  fflush(stdin);
  fgets(comp.tipo,20,stdin);
  printf("Referência do componente: ");
  fflush(stdin);
  fgets(comp.referencia,4,stdin);
  printf("Número da referência: ");
  scanf("%c",&comp.num_ref);
  getchar();
  printf("Valor do componente: ");
  scanf("%d",&comp.valor);
  getchar();
  printf("Unidade: ");
  fflush(stdin);
  fgets(comp.unidade,10,stdin);
  printf("_______________________\n");
  printf("\nCOMPONENTE CRIADO:\n\n");
  printf("%s",comp.tipo);
  printf("%s",comp.referencia);
  printf("%c",comp.num_ref);
  printf("\nValor: %d",comp.valor);
  printf("STRUT %s", comp.unidade);
}
