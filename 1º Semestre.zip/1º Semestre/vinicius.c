#include <stdio.h>
typedef struct {
    char nome[10];
    int numero;
} aluno;
int main () {
    aluno turma[10];
    char op[3];
    for (int i = 0; i < 10; i++) { // cadastrar
        printf("Voce deseja cadastrar, digite sim ou nao: "); scanf("%s", op);
        if (op[0] == 's') {
            printf("Nome: "); scanf("%s" turma[i].nome);
            printf("\nNumero: "); scanf("%i", turma[i].numero);
        }
        else {
            break;
        }
    }
    while (true) {  // procurar
        printf("Difite o numero para buscar: "); int numero; scanf("%i", &numero);
        if (numero == 0) {break;}
        else {
            for (int i = 0; i < 10; i++) {
                if (turma[i].numero == numero) {
                    printf("%s", turma[i].nome);
                    break;
                }
            }
        }
    }
    getchar ();
    return 0;
}
