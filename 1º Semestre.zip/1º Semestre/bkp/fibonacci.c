#include <stdio.h>
#include <stdlib.h>

int main(){

	int i,n1,n2,n3;

	n1=0;
	n2=1;
	n3=0;
	printf("%d\n",n1);
	printf("%d\n",n2);
	for(i=0;i<13;i++){
		n3=n1+n2;
		printf("%d\n",n3);
		n1=n2;
		n2=n3;
	}
	return 0;
}

