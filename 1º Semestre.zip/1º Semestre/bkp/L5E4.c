#include <stdio.h>
#include <stdlib.h>

int main(){
	
	int num[5][5];
	int i,j;
	
	for (i=0;i<5;i++){
		for(j=0;i<5;i++){
			num[j][i]=(j*5)+i+1;
		}
	}
	for (i=0;i<5;i++){
		for(j=0;i<5;i++){
			printf("%3d",num[j][i]);
		}
	printf("\n");
	}
	return 0;
}
