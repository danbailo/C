#include <stdio.h>

int main(){
	
	float M1[5], M2[5], M3[5];
	int i;
	
	printf("Digite 5 números:\n");
	for(i=0; i<5; i++){
		scanf("%f", &M1[i]);
	}
	printf("Digite 5 números:\n");
	for(i=0; i<5; i++){
		scanf("%f", &M2[i]);
	}
	for(i=0; i<5; i++){
		M3[i] = M1[i] * M2[i];
	}
	for(i=0; i<5; i++){
		printf("%0.0f * %0.0f = %0.0f\n", M1[i], M2[i], M3[i]);
	}
	return 0;
}
