#include <stdio.h>
#include <stdlib.h>

int main(){
	
	int i, dez[10];
	int maior=0,menor=0,igual=0;
	
	for(i=0;i<10;i++){
		printf("Digite o %dº número: ",i+1);
		scanf("%d",&dez[i]);
	}
	for(i=1;i<10;i++){
		if(dez[i]>dez[0]){
			maior++;
		}
		if(dez[i]<dez[0]){
			menor++;
		}
		if(dez[i]==dez[0]){
			igual++;
		}
	}
	printf("\nTotal de números maiores que o primeiro elemento é:%d",maior);
	printf("\nTotal de números menores que o primeiro elemento é:%d\n",menor);
	printf("Total de números iguais que o primeiro elemento é:%d",igual);
	return 0;
}
