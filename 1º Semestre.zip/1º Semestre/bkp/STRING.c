#include <stdio.h>
#include <string.h>

int main(){
	char nome[50];
	int i;
	
	printf("Digite seu nome: ");
	scanf("%s", nome); /*"N�O PRECISA DE &, POR QUE � UMA STRING"*/
	
	for(i=0; i<strlen(nome); i++){
		printf("%c\n", nome[i]);
	}
	return 0;
}
