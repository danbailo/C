#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){

	int n1,n2,maior,menor;

	printf("Digite dois números:\n");
	scanf("%d%d",&n1,&n2);
	if(n1>n2){
		maior=n1;
		menor=n2;
	}else{
		maior=n2;
		menor=n1;
	}
	printf("%d elevado a %d é igual a %0.0f", maior,menor,pow(maior,menor));
	return 0;
}