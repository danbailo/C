#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){

	int M1[5][3],i,j;

	setlocale(LC_ALL, "Portuguese");
	
	printf("Digite 15 n�meros inteiros:\n");
	for(i=0; i<5; i++)
		for(j=0; j<3; j++)
			scanf("%d", &M1[i][j]);
			
	printf("\n");
	for(i=0; i<5; i++){
		for(j=0; j<3; j++)
			printf("%d\t", M1[i][j]);
		printf("\n");
	}
	return 0;	
}
