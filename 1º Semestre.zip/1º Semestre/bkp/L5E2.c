#include <stdio.h>
#include <stdlib.h>

int main(){
	
	int i;
	float dez[10];
	
	for(i=0;i<10;i++){
		printf("Digite o %dº número:\n",i+1);
		scanf("%f",&dez[i]);
	}
	for(i=9;i>=0;i--){
		printf("\n%0.0f",dez[i]);
	}
	return 0;
}
