#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char quarenta[40];

int main(){    

    int i;

    printf("Digite algo:\n");
    gets(quarenta);
    /*fgets(quarenta,40,stdin);*/
    for(i=0;i<strlen(quarenta);i++){
		printf("Valor do elemento %d da string = %c\n",i, quarenta[i]);
	}
	return 0;
}
