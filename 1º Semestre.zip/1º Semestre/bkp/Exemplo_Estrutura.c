#include <stdio.h>
#include <locale.h>
#include <stdlib.h>


int main ()
{
	setlocale(LC_ALL, "Portuguese");
	
	struct Rest {
		char nome[30];
		char rua[50];
		unsigned int numero;
		unsigned long int fone;
		char cozinha[20];
		float preco_medio;
	};
	
struct Rest Rest_PPora;

printf("Cadastre o restaurante \n");
	printf("Nome o restaurante: \n");
	gets(Rest_PPora.nome);
	printf("Rua: ");
	gets(Rest_PPora.rua);
	printf("N�mero: ");
	scanf("%d", &Rest_PPora.numero);
	printf("Fone: ");
	scanf("%d", &Rest_PPora.fone);
	getchar();
	printf("Cozinha: ");
	gets(Rest_PPora.cozinha);
	printf("Preco Medio: ");
	scanf("%f", &Rest_PPora.preco_medio);
	getchar();
	
printf("\n");
printf("Restaurante: %s\n", Rest_PPora.nome);
printf("Rua: %s\n", Rest_PPora.rua);
printf("N�mero %d\n", Rest_PPora.numero);
printf("Fone %d\n", Rest_PPora.numero);
printf("Cozinha: %s\n", Rest_PPora.cozinha);
printf("Pre�o M�dio: %.2f\n", Rest_PPora.preco_medio);
}
