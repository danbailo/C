#include <stdio.h>
#include <stdlib.h>
int main(void)
{
   int i;
 
   /*declarando e atribuindo valores no vetor de char*/
   char texto[6] = "string";
 
   printf("Valor da variavel texto = %s\n", texto);
 
   /*Percorrendo o vetor de char e mostrando*/
   /*cada elemento individualmente*/
   for (i=0; i<6; i++)
   {
      printf("Valor do elemento %d da string = %c\n",i, texto[i]);
   }
 
   getch();
   return 0;
}