#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	struct Carro{
		char prop[32],
			fuel[32],
			mod[32],
			cor[32],
			plac[32];
		unsigned int chassi,ano;
	};
	struct Carro carros[20];
	int op;
	char se[32];
	printf("CADASTRO\n");
	for(int i=0;i<20;i++){

		printf("Digite o proprietário do carro %i:",i+1);
		fgets(carros[i].prop,32,stdin);
		carros[i].prop[strlen(carros[i].prop)-1]='\0';

		printf("Digite o tipo de combustivel do carro %i:",i+1);
		fgets(carros[i].fuel,32,stdin);
		carros[i].fuel[strlen(carros[i].fuel)-1]='\0';

		printf("Digite a cor do carro %i:",i+1);
		fgets(carros[i].cor,32,stdin);
		carros[i].cor[strlen(carros[i].cor)-1]='\0';

		printf("Digite o modelo do carro %i:",i+1);
		fgets(carros[i].mod,32,stdin);
		carros[i].mod[strlen(carros[i].mod)-1]='\0';

		printf("Digite a placa do carro %i:",i+1);
		fgets(carros[i].plac,32,stdin);
		carros[i].plac[strlen(carros[i].plac)-1]='\0';


		printf("Digite o número de chassi do carro %i:",i+1);
		scanf("%i",&carros[i].chassi);
		printf("Digite o ano do carro %i:",i+1);
		scanf("%i",&carros[i].ano);
		getchar();
	}
	printf("CONSULTA\n");
	op=1;
	while(op){
		printf("Escolha a operação\n");
		printf("Digite 1 para consultar por cor\n");
		printf("Digite 2 para consultar por placa\n");
		printf("Digite 0 para sair\n");

		scanf("%i",&op);
		getchar();
		if(op==1){
				printf("Digite a cor a ser consultada:");
				fgets(se,32,stdin);
				se[strlen(se)-1]='\0';
				for(int i=0;i<20;i++){
					if(!strcmp(se,carros[i].cor)){
						printf("Proprietário:%s combustivel:%s cor:%s placa:%s\n",carros[i].prop,carros[i].fuel,carros[i].cor,carros[i].plac);
						printf("Modelo:%s No. de chasssi:%i ano:%i\n\n",carros[i].mod,carros[i].chassi,carros[i].ano);
					}
				}
			}
		else if(op==2){
				printf("Digite a placa a ser consultada:");
				fgets(se,32,stdin);
				se[strlen(se)-1]='\0';
				for(int i=0;i<20;i++){
					if(!strcmp(se,carros[i].plac)){
						printf("Proprietário:%s combustivel:%s cor:%s placa:%s\n",carros[i].prop,carros[i].fuel,carros[i].cor,carros[i].plac);
						printf("Modelo:%s No. de chasssi:%i ano:%i\n\n",carros[i].mod,carros[i].chassi,carros[i].ano);
						break;
					}
				}
		}
		else if(op==0){
			printf("Saindo ....\n");
		}
		else {
			printf("Operação invalida\n");
		}
	}
}
