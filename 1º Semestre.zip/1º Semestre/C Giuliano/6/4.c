#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	struct Cad{
		char nome[32];
	 	unsigned int idade,
	 				cod;//0:Programação 1:linux 2:gerencia de redes
	 	unsigned long int tel;
	};
	int n0=0,n1=0,n2=0,op=1;
	struct Cad cads[100];
	printf("CADASTRO\n");
	for(int i=0;i<100;i++){
		printf("Digite o nome do aluno %i:",i+1);
		fgets(cads[i].nome,32,stdin);
		cads[i].nome[strlen(cads[i].nome)-1]='\0';

		printf("Digite a idade do aluno %i:",i+1);
		scanf("%i",&cads[i].idade);

		printf("Digite o telefone do aluno %i:",i+1);
		scanf("%lu",&cads[i].tel);

		printf("Digite o codigo de curso do aluno %i:",i+1);
		scanf("%i",&cads[i].cod);
		switch(cads[i].cod){
			case 0:
				n0++;
				break;
			case 1:
				n1++;
				break;
			case 2:
				n2++;
				break;
			default:
				printf("Erro, codigo invalido");
				return 0;
		}

		getchar();
	}
	printf("Há %i alunos cadastrados no curso de programação\n",n0);
	printf("Há %i alunos cadastrados no curso de linux\n",n1);
	printf("Há %i alunos cadastrados no curso de gerencia de redes\n\n",n2);
	while(op){
		printf("Digite 1 para listar os alunos cadastrados no curso de programação\n");
		printf("Digite 2 para listar os alunos cadastrados no curso de linux\n");
		printf("Digite 3 para listar os alunos cadastrados no curso de gerencia de redes\n");
		printf("Digite 0 para parar o programa\n");

		scanf("%i",&op);
		if(op==0){
			break;
		}
		op--;
		for(int i=0;i<100;i++){
			if(cads[i].cod==op){
				printf("Nome:%s Telefone:%lu Idade:%u\n",cads[i].nome,cads[i].tel,cads[i].idade);
			}
		}
	}
}