#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
int main(){
	time_t t=time(NULL);
	struct tm tm=*localtime(&t);

	int ano=tm.tm_year + 1900;

	struct Cad{
		char nome[32],
			rua[64],
			bairro[64];
	 	unsigned long int tel;
	 	unsigned int sal,ano_cad,ult_cmp,cod;
	};
	int n0=0,n1=0,n2=0,n3=0,i=0;
	int op=1;
	struct Cad cads[1500];
	printf("CADASTRO\n");
	while(op&&i<1500){
		printf("Digite o nome do %dº cliente: ",i+1);
		gets(cads[i].nome);
		printf("Digite a rua do %dº cliente: ",i+1);
		gets(cads[i].rua);
		printf("Digite o bairro do %dº cliente: ",i+1);
		gets(cads[i].bairro);
		printf("Digite o telefone do %dº cliente: ",i+1);
		scanf("%lu",&cads[i].tel);
		printf("Digite o salario do %dº cliente: ",i+1);
		scanf("%d",&cads[i].sal);
		printf("Digite o valor da última do compra do %dº cliente: ",i+1);
		scanf("%d",&cads[i].ult_cmp);
		printf("Digite o ano de cadastro do %dº cliente: ",i+1);
		scanf("%d",&cads[i].ano_cad);
		int temp_cad=ano-cads[i].ano_cad;
		if( temp_cad <0 ){
			printf("Erro, usuario se cadastrou no futuro?\n");
			return 0;
		}
		else if(temp_cad<3){
			n0++;
			cads[i].cod=0;
		}
		else if(temp_cad<6){
			n1++;
			cads[i].cod=1;
		}
		else if(temp_cad<10){
			cads[i].cod=2;
			n2++;
		}
		else{
			cads[i].cod=3;
			n3++;
		}
		printf("\n");
		printf("Nome do cliente: %s\nTelefone do cliente: %lu\n",cads[i].nome,cads[i].tel);
		printf("Desconto de %d%%\n",cads[i].cod+1);
		printf("Valor da última compra com desconto: %.2f\n",(float)cads[i].ult_cmp*(1.00-(0.01*( cads[i].cod+1))));
		printf("Digite 0 para parar o programa ou qualquer outro simbolo para continuar !\n");
		scanf("%d",&op);
		getchar();
		i++;
	}
	printf("Há %d clientes com o tempo de cadastro entre 0 a 2 anos\n",n0);
	printf("Há %d clientes com o tempo de cadastro entre 3 a 5 anos\n",n1);
	printf("Há %d clientes com o tempo de cadastro entre 6 a 9 anos\n",n2);
	printf("Há %d clientes com o tempo de cadastro com mais de 10 anos\n",n3);
	printf("Foram lidos %d clientes\n",i);
	return 0;
}
