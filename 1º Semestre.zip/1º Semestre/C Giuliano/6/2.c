#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	struct Aluno{
		unsigned long int rga;
		char nome[10];
		float nota;
	};
	struct Aluno alunos[10];
	char c;
	unsigned long int rgas[10];
	char nomes[10][32];
	float notas[10];
	for(int i=0;i<10;i++){
		printf("Digite o RGA do aluno %i:",i+1);
		scanf("%i",&rgas[i]);
		getchar();
		printf("Digite o nome do aluno %i:",i+1);
		fgets(nomes[i],32,stdin);
		nomes[i][strlen(nomes[i])-1]='\0';
		printf("Digite a nota do aluno %i:",i+1);
		scanf("%f",&notas[i]);
	}
	for(int i=0;i<10;i++){
		for(int j=0;c=nomes[i][j];j++){
			alunos[i].nome[j]=c;
		}

		alunos[i].rga=rgas[i];
		alunos[i].nota=notas[i];
	}
	return 0;
}
