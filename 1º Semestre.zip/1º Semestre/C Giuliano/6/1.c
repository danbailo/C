#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	struct Cad{
		unsigned long int no;
		char nome[32];
	};
	struct Cad cads[10];
	char se[32];
	int op=1,f;
	printf("CADASTRO\n");
	for(int i=0;i<10;i++){
		printf("Digite o número do aluno %i:",i+1);
		scanf("%i",&cads[i].no);
		getchar();
		printf("Digite o nome do aluno %i:",i+1);
		fgets(cads[i].nome,32,stdin);
		cads[i].nome[strlen(cads[i].nome)-1]='\0';

	}
	printf("PESQUISAR ALUNO\n");
	while(op){
		printf("Digite o nome do aluno:");
		fgets(se,32,stdin);
		se[strlen(se)-1]='\0';
		f=0;
		for(int i=0;i<10;i++){
			if(!strcmp(cads[i].nome,se)){
				printf("Aluno:%s Número:%i\n",cads[i].nome,cads[i].no);
				f=1;
				break;
			}
		}
		if(!f){
			printf("Aluno não encontrado\n");
		}
		printf("Digite 0 para para sair ou qualquer numero para continuar:");
		scanf("%i",&op);
		getchar();
	}
	return 0;
}
