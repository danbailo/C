#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	struct Carro{
		char prop[32];
		char fuel[32];
		char mod[32];
		char cor[32];
		char plac[32];
		unsigned int chassi,ano;
	};
	struct Carro car[20];
	int op;
	char se[32];
	printf("CADASTRO\n");
	for(int i=0;i<2;i++){
		printf("Digite o nome do proprietário do %dº carro: ",i+1);
		gets(car[i].prop);
		printf("Digite o tipo de combustivel do %dº carro: ",i+1);
		gets(car[i].fuel);
		printf("Digite a cor do %dº carro: ",i+1);
		gets(car[i].cor);
		printf("Digite o modelo do %dº carro: ",i+1);
		gets(car[i].mod);
		printf("Digite a placa do %dº carro: ",i+1);
		gets(car[i].plac);
		printf("Digite o número de chassi do %dº carro: ",i+1);
		scanf("%i",&car[i].chassi);
		printf("Digite o ano do %dº carro: ",i+1);
		scanf("%i",&car[i].ano);
		printf("\n");
		getchar();
	}
	printf("CONSULTA\n");
	op=1;
	while(op){
		printf("Escolha a operação\n");
		printf("Digite 1 para consultar por cor\n");
		printf("Digite 2 para consultar por placa\n");
		printf("Digite 0 para sair\n");

		scanf("%i",&op);
		getchar();
		if(op==1){
				printf("Digite a cor a ser consultada:");
				gets(se);
				printf("\n");
				for(int i=0;i<20;i++){
					if(!strcmp(se,car[i].cor)){
						printf("Proprietário: %s\nCombustivel: %s\nCor: %s\nPlaca: %s\n",car[i].prop,car[i].fuel,car[i].cor,car[i].plac);
						printf("Modelo: %s\nNº de Chassi: %i\nAno: %i\n\n",car[i].mod,car[i].chassi,car[i].ano);
					}
				}
			}
		else if(op==2){
				printf("Digite a placa a ser consultada:");
				gets(se);
				printf("\n");
				for(int i=0;i<20;i++){
					if(!strcmp(se,car[i].plac)){
						printf("Proprietário: %s\nCombustivel: %s\nCor: %s\nPlaca: %s\n",car[i].prop,car[i].fuel,car[i].cor,car[i].plac);
						printf("Modelo: %s\nNº de Chassi: %i\nAno: %i\n\n",car[i].mod,car[i].chassi,car[i].ano);
						break;
					}
				}
		}
		else if(op==0){
			printf("Você escolheu sair!\n");
		}
		else {
			printf("Operação inválida!\n");
		}
	}
}
