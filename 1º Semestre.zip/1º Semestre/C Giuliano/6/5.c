#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
int main(){
	time_t t=time(NULL);
	struct tm tm=*localtime(&t);
	
	int ano=tm.tm_year + 1900;

	struct Cad{
		char nome[32],
			rua[64],
			bairro[64];
	 	unsigned long int tel;
	 	unsigned int sal,ano_cad,ult_cmp,cod; 
	};
	int n0=0,n1=0,n2=0,n3=0,i=0;
	int op=1;
	struct Cad cads[1500];
	printf("CADASTRO\n");
	while(op&&i<1500){
		printf("Digite o nome do cliente %i:",i+1);
		fgets(cads[i].nome,32,stdin);
		cads[i].nome[strlen(cads[i].nome)-1]='\0';

		printf("Digite a rua do cliente %i:",i+1);
		fgets(cads[i].rua,32,stdin);
		cads[i].rua[strlen(cads[i].rua)-1]='\0';

		printf("Digite o bairro do cliente %i:",i+1);
		fgets(cads[i].bairro,32,stdin);
		cads[i].bairro[strlen(cads[i].bairro)-1]='\0';

		printf("Digite o telefone do cliente %i:",i+1);
		scanf("%lu",&cads[i].tel);

		printf("Digite o salario do cliente %i:",i+1);
		scanf("%i",&cads[i].sal);

		printf("Digite o valor da ultima compra %i:",i+1);
		scanf("%i",&cads[i].ult_cmp);

		printf("Digite o ano de cadastro %i:",i+1);
		scanf("%i",&cads[i].ano_cad);

		int temp_cad=ano-cads[i].ano_cad;
		
		
		if( temp_cad <0 ){
			printf("Erro, usuario se cadastrou no futuro?\n");
			return 0;
		}
		else if(temp_cad<3){
			n0++;
			cads[i].cod=0;
		}
		else if(temp_cad<6){
			n1++;
			cads[i].cod=1;
		}
		else if(temp_cad<10){
			cads[i].cod=2;
			n2++;
		}
		else{
			cads[i].cod=3;
			n3++;
		}
		printf("Nome do cliente:%s telefone do cliente:%lu\n",cads[i].nome,cads[i].tel);
		printf("Desconto de %i%%\n",cads[i].cod+1);
		printf("Valor da ultima compra com desconto:%f\n",(float)cads[i].ult_cmp*(1.00-(0.01*( cads[i].cod+1)) ) );
		
		printf("Digite 0 para parar o programa ou qualquer outro simbolo para continuar\n");
		scanf("%i",&op);
		getchar();
		i++;
	}


	printf("Há %i clientes com o tempo de cadastro entre 0 a 2 anos\n",n0);
	printf("Há %i clientes com o tempo de cadastro entre 3 a 5 anos\n",n1);
	printf("Há %i clientes com o tempo de cadastro entre 6 a 9 anos\n",n2);
	printf("Há %i clientes com o tempo de cadastro com mais de 10 anos\n",n3);
	printf("Foram lidos %i clientes\n",i);
	return 0;
}