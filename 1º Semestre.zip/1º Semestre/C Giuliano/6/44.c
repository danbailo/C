#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(){
	struct Cad{
		char nome[32];
	 	unsigned int idade;
	 	unsigned int cod;
	 	unsigned long int tel;
	};
	int n0=0,n1=0,n2=0,op=1;
	struct Cad cads[100];
	printf("CADASTRO\n");
	for(int i=0;i<100;i++){
		printf("Digite o nome do %dº aluno: ",i+1);
		gets(cads[i].nome);
		fflush(stdin);
		printf("Digite a idade do %dº aluno: ",i+1);
		scanf("%d",&cads[i].idade);
		printf("Digite o telefone do %dº aluno: ",i+1);
		scanf("%lu",&cads[i].tel);
		printf("Digite o codigo de curso do %dº aluno: ",i+1);
		scanf("%d",&cads[i].cod);
		getchar();
		printf("\n");
		if(cads[i].cod==0)
				n0++;
		if(cads[i].cod==1)
				n1++;
		if(cads[i].cod==2)
				n2++;
		getchar();
	}
	printf("Há %d alunos cadastrados no curso de programação\n",n0);
	printf("Há %d alunos cadastrados no curso de linux\n",n1);
	printf("Há %d alunos cadastrados no curso de gerencia de redes\n\n",n2);
	while(op){
		printf("Digite 1 para listar os alunos cadastrados no curso de programação\n");
		printf("Digite 2 para listar os alunos cadastrados no curso de linux\n");
		printf("Digite 3 para listar os alunos cadastrados no curso de gerencia de redes\n");
		printf("Digite 0 para parar o programa\n");
		scanf("%d",&op);
		if(op==0){
			break;
		}
		op--;
		for(int i=0;i<100;i++){
			if(cads[i].cod==op){
				printf("Nome:%s Telefone:%lu Idade:%u\n",cads[i].nome,cads[i].tel,cads[i].idade);
			}
		}
	}
}
