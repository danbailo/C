#include <stdio.h>
#include <math.h>
int main(){
	int m[20];
	int s=0;
	for(int i=0;i<20;i++){
		printf("Digite o %i elemento:",i+1);
		scanf("%i",&m[i]);
	}
	for(int i=0;i<10;i++){
		s+=pow(m[i]-m[19-i],3);
	}
	printf("Somatorio =%i",s);
	return 0;
}