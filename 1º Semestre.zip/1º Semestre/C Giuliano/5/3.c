#include <stdio.h>
int main(){
	int arr[10];
	int ma=0,me=0,ig=0;
	int i;
	for(i=0;i<10;i++){
		printf("Digite o %i elemento:",i+1);
		scanf("%i",&arr[i]);
	}
	for(i=1;i<10;i++){
		if(arr[i]>arr[0]){
			ma++;
		}
		else if(arr[i]<arr[0]){
			me++;
		}
		else{
			ig++;
		}
	}
	printf("Numero de elementos maior que o primeiro elemento da matriz:%i\n",ma);
	printf("Numero de elementos menor que o primeiro elemento da matriz:%i\n",me);
	printf("Numero de elementos igual que o primeiro elemento da matriz:%i\n",ig);
	return 0;
}
