#include <stdio.h>
int main(){
	int m[5][5];
	int s1=0;
	float s2=0;
	for(int i=0;i<5;i++){
		for(int j=0;j<5;j++){
			printf("Escreva o numero da linha %i coluna %i da matriz:",i,j);
			scanf("%i",&m[i][j]);
		}
	}
	for(int i=0;i<5;i++){
		for(int j=0;j<5;j++){
			if((i+j)<3){
				s1+=m[i][j];
			}
			else if((i+j)>3){
				s2+=m[i][j];
			}
		}
	}
	printf("Somatoria dos elementos acima da diagonal secundaria %i\n",s1);
	printf("Media dos elementos abaixo da diagonal secundaria %.2f\n",s2/10.0);
	return 0;
}