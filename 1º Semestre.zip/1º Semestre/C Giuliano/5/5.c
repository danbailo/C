#include <stdio.h>
int main(){
	float arr[10];
	float ma,me;
	float s=0;
	for(int i=0;i<10;i++){
		while(1){
			printf("Digite o %i em celsius entre 0 e 50:",i+1);
			scanf("%f",&arr[i]);
			if(arr[i]>0 && arr[i]<50){
				break;
			}
			else{
				printf("Erro, digite novamente...\n");
			}
		}
	}
	ma=arr[0];
	me=arr[0];
	for(int i=0;i<10;i++){
		if(arr[i]>ma){
			ma=arr[i];
		}
		if(arr[i]<me){
			me=arr[i];
		}
		s+=arr[i];
	}
	printf("Maior valor %.2f\n",ma);
	printf("Menor valor %.2f\n",me);
	printf("Media dos valores %.2f\n",s/10.0);
	return 0;
}
