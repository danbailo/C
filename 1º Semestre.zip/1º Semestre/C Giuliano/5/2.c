#include <stdio.h>
int main(){
	
	int i;
	
	int arr[10];
	for(i=0;i<10;i++){
		printf("Digite o %i elemento:",i+1);
		scanf("%d",&arr[i]);
	}
	for(i=9;i>=0;i--){
		printf("%d\n",arr[i]);
	}
	return 0;
}
