#include <stdio.h>
int main(){
	int m[4][4];
	int sp=0,ss=0;
	for(int i=0;i<4;i++){
		for(int j=0;j<4;j++){
			printf("Escreva o numero da linha %i coluna %i da matriz:",i,j);
			scanf("%i",&m[i][j]);
		}
	}
	for(int i=0;i<4;i++){
		for(int j=0;j<4;j++){
			if(i==j){
				sp+=m[i][j];
			}
			else if( (i+j)==3){
				ss+=m[i][j];
			}
		}
	}
	if(sp>ss){
		printf("A somatoria da diagonal principal é a maior e vale %i",sp);
	}
	else if(sp<ss){
		printf("A somatoria da diagonal secundária é a maior e vale %i",ss);
	}
	else{
		printf("A somatoria da diagonal principal e secundária sao iguais e valem %i",sp);
	}
	return 0;
}
