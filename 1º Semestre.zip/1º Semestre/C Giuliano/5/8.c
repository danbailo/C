#include <stdio.h>
int main(){
	int m[3][3];
	int s,n=0;
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			printf("Escreva o numero da linha %i coluna %i da matriz:",i,j);
			scanf("%i",&m[i][j]);
		}
	}
	printf("Numeros que sao perfeitos dessa matriz\n");
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			n=m[i][j];
			s=0;
			for(int k=1;k<n;k++){
				if((n%k)==0){
					s+=k;
				}
			}
			if(s==n){
				printf("%i\n",n);
			}
		}
	}

	return 0;
}
