#include <stdio.h>
int main(){
	int m[5][5];
	int s=0;
	for(int i=0;i<5;i++){
		for(int j=0;j<5;j++){
			printf("Escreva o numero da linha %i coluna %i da matriz:",i,j);
			scanf("%i",&m[i][j]);
		}
	}
	for(int i=0;i<5;i++){
		putchar('\n');
		for(int j=0;j<5;j++){
			if(i==j){
				s+=m[i][j];
			}
		}
	}
	printf("Somatória da diagonal principal %i\n",s);
	return 0;
}