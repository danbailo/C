#include <stdio.h>
#include <string.h>

char s[40];

int main(){
	
	int i;
	
	size_t ss;
	
	printf("Escreva uma palavra:");
	scanf("%s",s);
	ss=strlen(s);
	for(i=0;i<ss;i++){
		printf("%c S\n",s[i]);
	}
	putchar('\n');
	return 0;
}
