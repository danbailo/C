#include<stdio.h>
#include<string.h>
#define A 10

	typedef struct cad_aluno
	{
		char nome[10];
		int nro;
	}cad;

	//Principal
	int main(){
		int i, cot=1, local=0;

		cad c[A];

			for(i=0;i<A;i++){
				printf("Nome do %dº aluno: ",i+1);
				fflush(stdin);
				gets(c[i].nome);
				fflush(stdin);
				printf("Numero do %dº aluno: ",i+1);
				scanf("%d",&c[i].nro);
				printf("\n");
				getchar();
		}
		printf("Digite o numero do aluno:\n");
		scanf("%d",&local);
			if(local>0){
				for(i=0; i<A; i++){
					if(c[i].nro == local){
						printf("\nO aluno é: %s",c[i].nome);
					}
				}
			}
	return 0;
}
