#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
  int matriz[10];
  int c=0,cc=0,ccc=0;

  printf("Digite 10 números:\n");
  for(int i=0; i<10; i++){
    printf("%dº valor ",i+1);
    scanf("%d",&matriz[i]);
  }
  printf("\n");
  printf("MATRIZ\n");
  for(int i=0; i<10; i++){
    printf("%d\n",matriz[i]);
    if(i!=0){
      if(matriz[i]>matriz[0]){
        c++;
      }
      if(matriz[i]<matriz[0]){
        cc++;
      }
      if(matriz[i]==matriz[0]){
        ccc++;
      }      
    }
  }
  printf("%d elementos são maiores que o primeiro elemento da matriz\n",c);
  printf("%d elementos são menores que o primeiro elemento da matriz\n",cc);
  printf("%d elementos são iguais que o primeiro elemento da matriz\n",ccc);
}
