#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
  int matriz[10];
  float maior=0,menor=0;
  float media=0;

  printf("Digite 10 valores entre 0 e 50:\n");
  for(int i=0; i<10; i++){
    printf("%dº valor: ",i+1);
    scanf("%d",&matriz[i]);
  }
  maior=matriz[0];
  menor=matriz[0];
  for(int i=0; i<10; i++){
    if(maior<matriz[i]){
      maior=matriz[i];
    }
    if(menor>matriz[i]){
      menor=matriz[i];
    }
    media+=matriz[i];
  }
  printf("O maior valor é %.0f\n",maior);
  printf("O menor valor é %.0f\n",menor);
  printf("A temperatura média é %.2f",media/10);
}
