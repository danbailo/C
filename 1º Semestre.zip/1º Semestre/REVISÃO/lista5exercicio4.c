#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
  int matriz[5][5];
  int s;

  printf("Digite 25 números:\n");
  for(int i=0;i<5;i++){
    for(int j=0; j<5; j++){
      printf("Número da linha %d e coluna %d: ",i,j);
      scanf("%d",&matriz[i][j]);
    }
  }
  printf("\n");
  for(int i=0;i<5;i++){
    for(int j=0; j<5; j++){
      printf("%3d ",matriz[i][j]);
    }
    printf("\n");
  }
  for(int i=0;i<5;i++){
    s+=matriz[i][i];
  }
  printf("O somatório da matriz principal é %d",s);
}
