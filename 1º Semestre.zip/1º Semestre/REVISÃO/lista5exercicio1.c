#include <stdio.h>
#include <stdio.h>
#include <string.h>

char matriz[40];

int main() {

  printf("Digite qualquer coisa: ");
  gets(matriz);
  for(int i=0; i<strlen(matriz); i++){
    printf("%dº símbolo: %c\n",i,matriz[i]);
  }
  return 0;
}
