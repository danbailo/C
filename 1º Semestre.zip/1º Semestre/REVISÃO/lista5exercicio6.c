#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(){
  int matriz[20];
  float s=0;

  printf("Digite 20 valores\n");
  for(int i=0;i<20;i++){
    printf("%dº valor: ",i+1);
    scanf("%d",&matriz[i]);
  }
  printf("\n");
  for(int i=0;i<10;i++){
    s+=pow(matriz[i]-matriz[19-i],3);
  }
  printf("O somatório é %.0f", s);
}
