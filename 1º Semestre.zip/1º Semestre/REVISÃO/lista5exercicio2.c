#include <stdio.h>
#include <stdio.h>
#include <string.h>

int main(){
  float matriz[10];

  printf("Digite 10 números:\n");
  for(int i=0; i<10; i++){
    printf("%dº valor ",i+1);
    scanf("%f",&matriz[i]);
  }
  printf("\n");
  for(int i=9; i>=0; i--){
    printf("%dº valor %0.0f\n",i+1,matriz[i]);
  }
}
