#include <stdio.h>
#include <stdlib.h>

int main(){
  int i,cc,c;
  float dez[10];

  c=1;
  for(i=0;i<10;i++){
    printf("Digite o %dº número: ",c);
    scanf("%f",&dez[i]);
    c=c+1;
  }
  cc=1;
  for(i=9;i>=0;i--){
    printf("\n%dº valor é: %.0f",cc,dez[i]);
    cc=cc+1;
  }
  return 0;
}
