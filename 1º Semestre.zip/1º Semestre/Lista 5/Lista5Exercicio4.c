#include <stdio.h>
#include <stdlib.h>

int main(){

  int matriz[5][5];
  int i,j;
  int soma;
  soma=0;
  printf("Digite algum número:\n");
  for(i=0;i<5;i++){
    for(j=0;j<5;j++){
      scanf("%d,\n",&matriz[i][j]);
    }
    printf("\n");
  }
  for(i=0;i<5;i++){
    for(j=0;j<5;j++){
      printf("%d ",matriz[i][j]);
    }
    printf("\n\n");
  }
  for( j = 0; j < 5; j++ ) {
    soma += matriz[j][j];
  }
  printf("Soma da diagonal principal: %d", soma);
}
