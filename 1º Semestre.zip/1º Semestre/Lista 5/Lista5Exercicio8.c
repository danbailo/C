#include <stdio.h>
#include <stdlib.h>

int main() {
    int matriz[3][3];
    int n,s;

    printf("Digite 9 números\n");
    for(int i=0; i<3 ; i++){
      for(int j=0; j<3; j++){
          printf("Digite o número da linha %i e coluna %i: ",i,j);
        scanf("%i", &matriz[i][j]);
      }
    }
    printf("\nOs números perfeitos dessa matriz serão digitados abaixo:\n");
    for(int i=0; i<3 ; i++){
      for(int j=0; j<3; j++){
          n=matriz[i][j];
          s=0;
          for(int k=1;k<n;k++){
              if((n%k)==0){
                  s+=k;
              }
          }
          if(s==n){
              printf("%i\n",n);
          }
      }
    }
}
