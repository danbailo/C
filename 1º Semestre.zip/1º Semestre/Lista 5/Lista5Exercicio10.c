#include <stdio.h>
#include <stdlib.h>

int main(){
  int matriz[5][5];
  int soma1=0;
  float soma2=0;

  printf("Digite 25 números\n");
  for(int i=0; i<5; i++){
    for(int j=0; j<5; j++){
      printf("Digite o número da linha %d e coluna %d: ",i,j);
      scanf("%d", &matriz[i][j]);
    }
  }
  for(int i=0; i<5; i++){
    for(int j=0; j<5; j++){
      printf("%3d",matriz[i][j]);
      if(i+j<5-1){
        soma1+=matriz[i][j];
      }
      else if(i+j>=5){
        soma2+=matriz[i][j];
      }
    }
    printf("\n");
  }
  printf("O somatório dos elementos que estão acima da diagonal secundária é %d\n",soma1);
  printf("O média dos elementos que estão abaixo da diagonal secundária é %0.2f\n",soma2/10);
}
