#include <stdio.h>
#include <stdlib.h>

int main(){

  int matriz[5][5];
  int s1=0;
  float s2=0;

  printf("Digite 25 números\n");
  for(int i=0; i<5; i++){
    for(int j=0; j<5; j++){
      printf("Digite o número da linha %i e coluna %i: ",i,j);
      scanf("%i",&matriz[i][j]);
    }
  }
  for(int i=0; i<5; i++){
    for(int j=0; j<5; j++){
      if(j<i){
				s1+=matriz[i][j];
      }
      if(j>i){
        s2+=matriz[i][j];
      }
      printf("%i ",matriz[i][j]);
    }
    printf("\n");
  }
  printf("Somatoria dos elementos acima da diagonal principal %i\n",s1);
  printf("Média dos elementos abaixo da diagonal principal %.2f\n",s2/10.0);
}
