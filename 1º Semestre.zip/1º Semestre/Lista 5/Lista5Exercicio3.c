#include <stdio.h>
#include <stdlib.h>

int main(){
  int i;
  int dez[10];
  int maior,menor,igual;
  maior=0;
  menor=0;
  igual=0;
  for(i=0;i<10;i++){
    printf("Digite o %dº número: ",i+1);
    scanf("%d",&dez[i]);
    if(i!=0){
      if(dez[i]>dez[0]){
        maior++;
      }
      if(dez[i]<dez[0]){
        menor++;
      }
      if(dez[i]==dez[0]){
        igual++;
      }
    }
  }
  printf("\n%d números são maiores que o primeiro elemento da matriz",maior);
  printf("\n%d números são menores que o primeiro elemento da matriz",menor);
  printf("\n%d números são iguais que o primeiro elemento da matriz",igual);
}
