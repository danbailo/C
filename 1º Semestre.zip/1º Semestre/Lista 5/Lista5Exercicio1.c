#include <stdio.h>
#include <string.h>

char quarenta[40];

int main(){

  int i;

  printf("Digite algo: ");
  fgets(quarenta,40,stdin);
  quarenta[strlen(quarenta)-1]='\0';
  for(i=0;i<strlen(quarenta);i++){
    printf("\n\n%dº símbolo:%c ",i,quarenta[i]);
  }
  return 0;
}
