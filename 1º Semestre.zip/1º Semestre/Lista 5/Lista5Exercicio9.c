#include <stdio.h>
#include <stdlib.h>

int main(){
  float matriz[4][4];
  int soma1=0,soma2=0;

  printf("Digite 16 números\n");
  for(int i=0; i<4; i++){
    for(int j=0; j<4; j++){
      printf("Digite o numero da linha %d e coluna %d: ",i,j);
      scanf("%f",&matriz[i][j]);
    }
  }
  for(int i=0; i<4; i++){
    for(int j=0; j<4; j++){
      if(i==j){
        soma1+=matriz[i][j];
      }
      if(i+j==4-1){
        soma2+=matriz[i][j];
      }
      printf("%3.0f",matriz[i][j]);
    }
    printf("\n");
  }
  printf("Soma da diagonal principal: %d\n", soma1);
  printf("Soma da diagonal secundária: %d\n", soma2);
  if(soma1>soma2){
    printf("O somatorio da diagonal principal é maior e vale %d\n", soma1);
  }
  else if(soma1<soma2){
    printf("O somatorio da diagonal secundaria é maior e vale %d\n", soma2);
  }
  else{
    printf("A somatoria da diagonal principal e secundária são iguais e valem %d\n",soma1);
  }
}
