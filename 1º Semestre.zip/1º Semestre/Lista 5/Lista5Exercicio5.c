#include <stdio.h>
#include <stdlib.h>

int main(){
  float maior,menor,media=0;
  int matriz[10];

  for(int i=0;i<10;i++){
    while(1){
      printf("\nDigite o %dº valor em Celsius entre 0 e 50: ",i+1);
      scanf("%d",&matriz[i]);
      if(matriz[i]>0 && matriz[i]<=50){
        break;
      }
      else{
        printf("Por favor, digite um valor entre 0 e 50 !\n");
      }
    }
  }
  maior=matriz[0];
  menor=matriz[0];
  for(int i=0;i<10;i++){
    if(maior<matriz[i]){
      maior=matriz[i];
    }
    if(menor>matriz[i]){
      menor=matriz[i];
    }
    media=media+matriz[i];
  }
  printf("Maior valor em graus Celsius é %.2f\n",maior);
  printf("Menor valor em graus Celsius é %.2f\n",menor);
  printf("Media dos valores em graus Celsius é %.2f\n",media/10.0);
  return 0;
}
