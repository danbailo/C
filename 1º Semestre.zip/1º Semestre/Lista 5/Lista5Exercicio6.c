#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){

  float matriz[20];
  float soma=0;

  for(int i=0;i<20;i++){
    printf("Digite o %dº valor: ",i+1);
    scanf("%f",&matriz[i]);
  }
  for(int i=0;i<10;i++){
		soma+=pow(matriz[i]-matriz[19-i],3);
	}
	printf("Somatorio =%.0f",soma);
  return 0;
}
